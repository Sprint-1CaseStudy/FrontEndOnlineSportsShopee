import './App.css';
import CartHome from './components/customer/Cart';
import Login from './components/login/adminLogin';
import SignUp from './components/login/adminSignUp';
import Orders from './components/customer/getOrders';
import ChangePassword from './components/login/adminChangePassword';
import ProductHome from './components/customer/products';
import ViewProduct from './components/customer/viewProduct';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import AdminHome from './components/admin/products/ListProductComponent';
import updateProduct from './components/admin/products/UpdateProductComponent';
import addProduct from './components/admin/products/AddProductComponent';
import customerLogin from './components/login/customerLogin';
import customerSignup from './components/login/customerSignUp';
import customerChangePassword from './components/login/customerChangePassword';
import customerSignout from './components/login/CustomerSignout';

function App() {
  return (
    <div >
      <Router>
                <div className="container">
                    <Switch>
                          <Route path = "/adminlogin" exact component = {Login}></Route>
                          <Route path = "/adminsignup" component = {SignUp}></Route>
                          <Route path = "/adminchangepassword" component = {ChangePassword}></Route>
                          <Route path = "/home" component = {ProductHome}></Route> 
                          <Route path = "/order" component = {Orders}></Route> 
                          <Route path = "/view-Product/:id" component = {ViewProduct}></Route>
                          <Route path = "/cart" component = {CartHome}></Route>

                          <Route path = "/" exact component = {customerLogin}></Route>
                          <Route path = "/signup" component = {customerSignup}></Route>
                          <Route path = "/changepassword" component = {customerChangePassword}></Route>
                          <Route path = "/signout" component = {customerSignout}></Route>
                          <Route path = "/adminhome" component = {AdminHome}></Route>
                          <Route path = "/edit-product/:id" component = {updateProduct}></Route>
                          <Route path = "/add-product/:id" component = {addProduct}></Route>
                    </Switch>
                </div>
        </Router>
    </div>
  );
}

export default App;
