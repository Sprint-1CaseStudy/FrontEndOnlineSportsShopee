import axios from 'axios';

const Customer_API_BASED_URL = "http://localhost:8088/onlinesportshopee/customers";

class customerService {

    addCustomer(customer) {   
        return axios.post(Customer_API_BASED_URL + '/addCustomer',customer);
    }
    
    loginInCustomer(customer){
        return axios.post(Customer_API_BASED_URL + '/login',customer);
    }

    Signout()
    {
        return axios.post(Customer_API_BASED_URL + '/signout');
    }

}


export default new customerService()