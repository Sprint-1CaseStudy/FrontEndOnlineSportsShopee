import React, { Component } from 'react'
import customerService from '../../Services/CustomerService';

class Signout extends Component {
    constructor(props) {
        super(props)

        
    }

    componentDidMount(){
            window.sessionStorage.removeItem("custId");
            this.props.history.push('/');
    } 
}

export default Signout
