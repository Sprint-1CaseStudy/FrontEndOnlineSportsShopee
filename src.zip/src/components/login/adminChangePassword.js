import React , {Component } from 'react';

class changePassword extends Component {

    constructor(props) {
        super(props);
        this.state = {password: '',userId:'',userName: ''};
    
        this.handleuserId = this.handleuserId.bind(this);
        this.handleuserName = this.handleuserName.bind(this);
        this.handlePassword = this.handlePassword.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
      }
    
      handleuserId(event) {
        this.setState({userId: event.target.value}); //this.setState()
        console.log(event.target.value);
      }
    
      handlePassword(event) {
        this.setState({password: event.target.value}); //this.setState()
        console.log(event.target.value);
      }
    
      handleuserName(event){
        this.setState({userName: event.target.value}); //this.setState()
        console.log(event.target.value);
      }
    
      handleSubmit(event) {
        alert('A name was submitted: ' + this.state.userId +"\n A userName was submitted:"+ this.state.userName +"\n A password was submitted:"+ this.state.password);
        event.preventDefault();
      }

    render()
    {
        return(
            <div><br></br>
                <div class="card text-center col-md-6 offset-md-2 offset-md-3">
                    <div class="card-header">
                        <h1><b>Change Password</b></h1>
                    </div>
                    <div class="card-body">
                        <form >
                            <div className = "form-group">
                                <label class="card-title" class="col-sm-2 col-form-label" style={{ marginBottom:'15px'}} > User Id   : </label>
                                <input type="text" placeholder="User ID" name="userId" style={{ marginLeft:'14px'}} value={this.state.userId} onChange={this.handleuserId}/>
                            </div>
                            <div className = "form-group">
                                <label class="card-title" class="col-sm-2 col-form-label" style={{ marginBottom:'15px'}} > User Name : </label>
                                <input type="text" placeholder="User Name" name="userName" style={{ marginLeft:'15px'}} value={this.state.userName} onChange={this.handleuserName}/>
                            </div>
                            <div className = "form-group">
                                <label class="col-sm-2 col-form-label" > Password : </label>
                                <input type="password" placeholder="Password" name="password" style={{ marginLeft:'14px'}} value={this.state.password} onChange={this.handlePassword}/>
                            </div>
                            <div >
                                <button type="submit" className="btn btn-success" onClick={this.handleSubmit} style={{ margin:'20px'}}>Save</button>
                                <button className="btn btn-danger" style={{ margin:'20px'}}>Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        );
    }
}

export default  changePassword;